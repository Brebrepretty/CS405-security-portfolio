#include <iomanip>
#include <iostream>
#include <limits>
#include <string>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";

    char user_input[20];

    std::cout << "Enter a value: ";

    std::cin.getline(user_input, sizeof(user_input));

    if (std::cin.fail())
    {
        std::cout << "Error: Input exceeded maximum length of 19 characters." << std::endl;
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}