// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid
#include <cmath>        // std::isfinite

/// <summary>
/// A small result object used to return both the numeric result
/// and whether an overflow/underflow was detected.
/// </summary>
/// <typeparam name="T">The numeric type being tested</typeparam>
template <typename T>
struct NumericResult
{
    T value;            // The calculated value when successful
    bool overflow;      // True when overflow or underflow was detected
};

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// This version checks for overflow/underflow before each addition.
/// </summary>
/// <typeparam name="T">A type with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>A NumericResult object containing the result and overflow status</returns>
template <typename T>
NumericResult<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // For integer types, check boundaries before performing the addition.
        if constexpr (std::numeric_limits<T>::is_integer)
        {
            // Detect positive overflow
            if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
            {
                return { result, true };
            }

            // Detect negative underflow
            if (increment < 0 && result < std::numeric_limits<T>::lowest() - increment)
            {
                return { result, true };
            }
        }
        else
        {
            // For floating-point types, perform the addition in a temporary variable
            // and check whether the result is still finite.
            T temp = result + increment;

            if (!std::isfinite(temp))
            {
                return { result, true };
            }
        }

        result += increment;
    }

    return { result, false };
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (decrement * steps)
/// This version checks for overflow/underflow before each subtraction.
/// </summary>
/// <typeparam name="T">A type with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>A NumericResult object containing the result and overflow status</returns>
template <typename T>
NumericResult<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // For integer types, check boundaries before performing the subtraction.
        if constexpr (std::numeric_limits<T>::is_integer)
        {
            // Subtracting a positive value can cause underflow
            if (decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement)
            {
                return { result, true };
            }

            // Subtracting a negative value can cause overflow
            if (decrement < 0 && result > std::numeric_limits<T>::max() + decrement)
            {
                return { result, true };
            }
        }
        else
        {
            // For floating-point types, perform the subtraction in a temporary variable
            // and verify that the result remains finite.
            T temp = result - decrement;

            if (!std::isfinite(temp))
            {
                return { result, true };
            }
        }

        result -= decrement;
    }

    return { result, false };
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto result = add_numbers<T>(start, increment, steps);
    std::cout << +result.value << " | overflow: " << (result.overflow ? "true" : "false") << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);

    if (result.overflow)
    {
        std::cout << "operation blocked";
    }
    else
    {
        std::cout << +result.value;
    }

    std::cout << " | overflow: " << (result.overflow ? "true" : "false") << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);
    std::cout << +result.value << " | overflow: " << (result.overflow ? "true" : "false") << std::endl;

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);

    if (result.overflow)
    {
        std::cout << "operation blocked";
    }
    else
    {
        std::cout << +result.value;
    }

    std::cout << " | overflow: " << (result.overflow ? "true" : "false") << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}
