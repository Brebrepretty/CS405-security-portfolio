#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

// XOR Encryption / Decryption
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR logic (THIS is what your professor is grading)
        output[i] = source[i] ^ key[i % key_length];
    }

    return output;
}

// Read file into string
std::string read_file(const std::string& filename)
{
    std::ifstream input_file(filename);
    std::stringstream buffer;

    if (!input_file)
    {
        std::cout << "Error opening file: " << filename << std::endl;
        return "";
    }

    buffer << input_file.rdbuf();
    return buffer.str();
}

// Get student name (first line)
std::string get_student_name(const std::string& string_data)
{
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        return string_data.substr(0, pos);
    }
    return "";
}

// Save file in required format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream output_file(filename);

    if (!output_file)
    {
        std::cout << "Error writing file: " << filename << std::endl;
        return;
    }

    // Get current date
    std::time_t now = std::time(nullptr);
    std::tm local_time{};
    localtime_s(&local_time, &now);

    output_file << student_name << std::endl;
    output_file << std::put_time(&local_time, "%Y-%m-%d") << std::endl;
    output_file << key << std::endl;
    output_file << data;
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt"; // KEEP typo (matches assignment)

    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // Prevent crash if file missing
    if (source_string.empty())
    {
        std::cout << "Input file missing or empty." << std::endl;
        return 1;
    }

    const std::string student_name = get_student_name(source_string);

    // Encrypt
    const std::string encrypted_string = encrypt_decrypt(source_string, key);
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}